import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.srcmasngud.kasir',
  appName: 'SRC MASNGUD',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
