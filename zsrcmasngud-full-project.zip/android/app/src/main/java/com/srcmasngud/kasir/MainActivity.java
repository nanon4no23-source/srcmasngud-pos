package com.srcmasngud.kasir;

import android.os.Bundle;
import android.util.Log;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "MainActivity";
    private AndroidBluetoothPrinter bluetoothPrinter;
    private AndroidFileManager fileManager;
    private OnBackPressedCallback backPressedCallback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupPrinterBridge();
        setupBackButtonDispatcher();
    }

    @Override
    public void onStart() {
        super.onStart();
        setupPrinterBridge();
    }

    @Override
    public void onResume() {
        super.onResume();
        setupPrinterBridge();
    }

    private void setupBackButtonDispatcher() {
        backPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    WebView webView = null;
                    if (bridge != null) {
                        webView = bridge.getWebView();
                    }
                    if (webView == null && getBridge() != null) {
                        webView = getBridge().getWebView();
                    }
                    if (webView != null) {
                        webView.evaluateJavascript(
                            "(function() { if (typeof window.handleAndroidHardwareBack === 'function') { return window.handleAndroidHardwareBack(); } return false; })()",
                            new ValueCallback<String>() {
                                @Override
                                public void onReceiveValue(String value) {
                                    boolean handled = "true".equals(value) || "\"true\"".equals(value);
                                    if (!handled) {
                                        // If not handled by React (e.g. user double-pressed on home screen to exit), proceed to finish
                                        setEnabled(false);
                                        MainActivity.super.onBackPressed();
                                        setEnabled(true);
                                    }
                                }
                            }
                        );
                        return;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "handleOnBackPressed error", e);
                }
                setEnabled(false);
                MainActivity.super.onBackPressed();
                setEnabled(true);
            }
        };
        getOnBackPressedDispatcher().addCallback(this, backPressedCallback);
    }

    private synchronized void setupPrinterBridge() {
        if (bluetoothPrinter == null) {
            bluetoothPrinter = new AndroidBluetoothPrinter(this);
        }
        if (fileManager == null) {
            fileManager = new AndroidFileManager(this);
        }
        try {
            WebView webView = null;
            if (this.bridge != null) {
                webView = this.bridge.getWebView();
            }
            if (webView == null && getBridge() != null) {
                webView = getBridge().getWebView();
            }
            if (webView != null) {
                webView.addJavascriptInterface(bluetoothPrinter, "AndroidPrinter");
                webView.addJavascriptInterface(fileManager, "AndroidFileManager");
                Log.d(TAG, "AndroidPrinter & AndroidFileManager interfaces successfully attached to WebView");
            } else {
                Log.w(TAG, "WebView is null, will retry in onResume/onStart");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to attach native interfaces", e);
        }
    }

    @Override
    public void onBackPressed() {
        if (backPressedCallback != null && backPressedCallback.isEnabled()) {
            backPressedCallback.handleOnBackPressed();
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onDestroy() {
        if (bluetoothPrinter != null) {
            bluetoothPrinter.cleanup();
        }
        super.onDestroy();
    }
}


