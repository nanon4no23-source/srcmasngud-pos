package com.srcmasngud.kasir;

import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        // Pastikan WebView mengizinkan akses kamera hardware (WebRTC getUserMedia)
        if (this.bridge != null && this.bridge.getWebView() != null) {
            WebView webView = this.bridge.getWebView();
            webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
            
            final WebChromeClient defaultClient = this.bridge.getWebViewClient() != null ? null : null;
            webView.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onPermissionRequest(final PermissionRequest request) {
                    // Otomatis grant izin kamera & audio ke webview lokal
                    request.grant(request.getResources());
                }
            });
        }
    }
}
