package com.srcmasngud.kasir;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

