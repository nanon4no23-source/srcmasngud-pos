package com.srcmasngud.kasir;

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final String TAG = "MainActivity";
    private AndroidBluetoothPrinter bluetoothPrinter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupPrinterBridge();
    }

    @Override
    public void onStart() {
        super.onStart();
        setupPrinterBridge();
    }

    @Override
    public void onResume() {
        super.onResume();
        setupPrinterBridge();
    }

    private synchronized void setupPrinterBridge() {
        if (bluetoothPrinter == null) {
            bluetoothPrinter = new AndroidBluetoothPrinter(this);
        }
        try {
            WebView webView = null;
            if (this.bridge != null) {
                webView = this.bridge.getWebView();
            }
            if (webView == null && getBridge() != null) {
                webView = getBridge().getWebView();
            }
            if (webView != null) {
                webView.addJavascriptInterface(bluetoothPrinter, "AndroidPrinter");
                Log.d(TAG, "AndroidPrinter JavascriptInterface successfully attached to WebView");
            } else {
                Log.w(TAG, "WebView is null, will retry in onResume/onStart");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to attach AndroidPrinter interface", e);
        }
    }

    @Override
    public void onDestroy() {
        if (bluetoothPrinter != null) {
            bluetoothPrinter.cleanup();
        }
        super.onDestroy();
    }
}

