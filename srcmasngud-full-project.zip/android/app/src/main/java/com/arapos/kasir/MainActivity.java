package com.arapos.kasir;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
